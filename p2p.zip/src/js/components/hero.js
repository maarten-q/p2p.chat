import React from 'react'

export default (props) => {

  return (
    <div className='container hero'>
      <h1>No-nonsense video calls.</h1>
      <h5>No logins. No tracking. Free forever.</h5>
    </div>
  )

}
