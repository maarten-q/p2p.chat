require('babel-polyfill')
require('./sass/main.scss')
require('./js/app.js')
